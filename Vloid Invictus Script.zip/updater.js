const fs = require("fs");
const path = require("path");
const https = require("https");
const unzipper = require("unzipper");

module.exports = async function autoUpdate(ctx, githubConfig) {

  const zipUrl = `https://api.github.com/repos/${githubConfig.repo}/zipball/${githubConfig.branch}`;

  if (!fs.existsSync("temp")) fs.mkdirSync("temp");

  const zipPath = "temp/update.zip";

  await ctx.reply("⏳ Downloading update...");

  const file = fs.createWriteStream(zipPath);

  https.get(zipUrl, {
    headers: {
      "User-Agent": "TelegrafBot",
      "Authorization": `token ${githubConfig.token}`
    }
  }, (res) => {

    if (res.statusCode !== 200) {
      ctx.reply("❌ Gagal download update");
      return;
    }

    res.pipe(file);

    file.on("finish", () => {
      file.close(() => extractZip(zipPath, ctx));
    });

  });
};

function extractZip(zipPath, ctx) {
  const extractPath = "temp/extract";

  fs.createReadStream(zipPath)
    .pipe(unzipper.Extract({ path: extractPath }))
    .on("close", () => applyUpdate(extractPath, ctx));
}

function applyUpdate(extractPath, ctx) {
  const folder = fs.readdirSync(extractPath)[0];
  const sourcePath = path.join(extractPath, folder);

  copyRecursive(sourcePath, "./");

  ctx.reply("✅ Update selesai. Restarting...");
  setTimeout(() => process.exit(0), 1500);
}

function copyRecursive(src, dest) {
  fs.readdirSync(src).forEach(file => {

    // 🔒 Jangan overwrite config.js
    if (file === "config.js" || file === "node_modules") return;

    const srcPath = path.join(src, file);
    const destPath = path.join(dest, file);

    if (fs.statSync(srcPath).isDirectory()) {
      if (!fs.existsSync(destPath)) fs.mkdirSync(destPath);
      copyRecursive(srcPath, destPath);
    } else {
      fs.copyFileSync(srcPath, destPath);
    }
  });
}