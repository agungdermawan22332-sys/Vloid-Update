module.exports = {
  BOT_TOKEN: "BOT_TOKEN_ELU",
  ownerID: "ID_TELE_ELU",
};
